<?php
require_once 'config.php';

$q = $_GET['q'] ?? '';

$stmt = $pdo->prepare("SELECT id, name FROM authors WHERE name LIKE ?");
$stmt->execute(['%' . $q . '%']);

$results = [];
while ($row = $stmt->fetch()) {
    $results[] = ['id' => $row['name'], 'text' => $row['name']];
}

echo json_encode($results);
