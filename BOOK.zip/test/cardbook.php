<?php
require_once 'config.php';

// Проверяем ID книги
if (!isset($_GET['id'])) {
  die('ID книги не указан.');
}

$id = (int)$_GET['id'];

// Получаем книгу
$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch();

if (!$book) {
  die('Книга не найдена.');
}

// Получаем авторов
$stmt = $pdo->prepare("
  SELECT a.* FROM authors a
  JOIN book_author ba ON ba.author_id = a.id
  WHERE ba.book_id = ?
");
$stmt->execute([$id]);
$authors = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title><?= htmlspecialchars($book['title']) ?> — Карточка книги</title>
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
</head>
<link rel="shortcut icon" href="log.png" type="image/x-icon">
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <div class="content-wrapper p-5">
    <div class="card">
      <div class="card-header bg-primary text-white">
        <h3 class="card-title"><?= htmlspecialchars($book['title']) ?></h3>
      </div>
      <div class="card-body">
        <p><strong>Год выпуска:</strong> <?= htmlspecialchars($book['year']) ?></p>
        <p><strong>Издание:</strong> <?= htmlspecialchars($book['edition']) ?></p>
        <p><strong>Авторы:</strong> <?= implode(', ', array_column($authors, 'name')) ?></p>

        <?php if (!empty($book['description'])): ?>
          <p><strong>Описание:</strong><br><?= nl2br(htmlspecialchars($book['description'])) ?></p>
        <?php endif; ?>

        <?php if (!empty($book['buy_link'])): ?>
          <p><a href="<?= htmlspecialchars($book['buy_link']) ?>" class="btn btn-success" target="_blank">
            🔗 Где купить
          </a></p>
        <?php endif; ?>

        <a href="dashboard.php" class="btn btn-secondary">← Назад к списку</a>
      </div>
    </div>
  </div>

</div>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
