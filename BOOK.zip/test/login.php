<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($_POST['username'] === 'admin' && $_POST['password'] === '123') {
    $_SESSION['admin'] = true;
    header('Location: index.php');
    exit;
  } else {
    $error = "Неверный логин или пароль.";
  }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Логин — Библиотека</title>
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">
</head>
<link rel="shortcut icon" href="log.png" type="image/png">
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">Admin <b>Библиотека</b></div>
  <div class="card">
    <div class="card-body">
      <?php if (isset($error)) echo "<p class='text-danger'>$error</p>"; ?>
      <form method="POST">
        <input type="text" name="username" placeholder="Логин" class="form-control mb-2">
        <input type="password" name="password" placeholder="Пароль" class="form-control mb-2">
        <button class="btn btn-primary btn-block">Войти</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
