<?php
require_once 'config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $year = $_POST['year'];
    $edition = $_POST['edition'];
    $authors = $_POST['authors'] ?? [];

    $stmt = $pdo->prepare("INSERT INTO books (title, year, edition) VALUES (?, ?, ?)");
    $stmt->execute([$title, $year, $edition]);
    $bookId = $pdo->lastInsertId();


    foreach ($authors as $authorName) {

        $stmt = $pdo->prepare("SELECT id FROM authors WHERE name = ?");
        $stmt->execute([$authorName]);
        $authorId = $stmt->fetchColumn();

     
        if (!$authorId) {
            $stmt = $pdo->prepare("INSERT INTO authors (name) VALUES (?)");
            $stmt->execute([$authorName]);
            $authorId = $pdo->lastInsertId();
        }

       
        $stmt = $pdo->prepare("INSERT INTO book_author (book_id, author_id) VALUES (?, ?)");
        $stmt->execute([$bookId, $authorId]);
    }

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Добавить книгу</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

</head>
<link rel="shortcut icon" href="log.png" type="image/png">
<body class="p-5">
  <div class="container">
    <h1>➕ Добавить книгу</h1>

    <form method="POST">
      <div class="mb-3">
        <label for="title" class="form-label">Название книги</label>
        <input type="text" name="title" id="title" class="form-control" required>
      </div>

      <div class="mb-3">
        <label for="year" class="form-label">Год выпуска</label>
        <input type="number" name="year" id="year" class="form-control">
      </div>

      <div class="mb-3">
        <label for="edition" class="form-label">Издательство</label>
        <input type="text" name="edition" id="edition" class="form-control">
      </div>

      <div class="mb-3">
        <label for="authors" class="form-label">Авторы</label>
        <select name="authors[]" id="authors" class="form-control" multiple="multiple"></select>
      </div>

      <button type="submit" class="btn btn-success">Добавить книгу</button>
      <a href="index.php" class="btn btn-secondary">Отмена</a>
    </form>
  </div>

  <script>
    $(document).ready(function() {
      $('#authors').select2({
        tags: true,
        placeholder: "Выберите или добавьте авторов",
        minimumInputLength: 1,
        ajax: {
          url: 'authors_api.php',
          dataType: 'json',
          delay: 250,
          data: function (params) {
            return { q: params.term };
          },
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });
    });
  </script>
</body>
</html>
