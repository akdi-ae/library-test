<?php
// session_start();
require_once 'config.php';

// // Проверка авторизации
// if (!isset($_SESSION['admin'])) {
//   header("Location: login.php");
//   exit;
// }


$perPage = 10;


$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;

$stmt = $pdo->prepare("SELECT * FROM books ORDER BY id DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$books = $stmt->fetchAll();

$totalBooks = $pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
$totalPages = ceil($totalBooks / $perPage);

foreach ($books as &$book) {
  $stmt = $pdo->prepare("
    SELECT a.* FROM authors a
    JOIN book_author ba ON ba.author_id = a.id
    WHERE ba.book_id = ?
  ");
  $stmt->execute([$book['id']]);
  $book['authors'] = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Список книг — Библиотека</title>
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
  <style>
    body {
      background: #f4f6f9;
    }
    .content-header {
      margin-bottom: 1rem;
    }
    table th, table td {
      vertical-align: middle !important;
    }
  </style>
</head>
<link rel="shortcut icon" href="log.png" type="image/x-icon">
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
      📚 <span class="brand-text font-weight-light">Библиотека</span>
    
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column">
          <li class="nav-item">
            <a href="login.php" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>Книги</p>
            </a>
          </li>
        </ul>
      </nav>
    </div>
  </aside>


  <div class="content-wrapper p-4">
    <section class="content-header">
      <h1>📄 Список всех книг</h1>
      <p class="text-muted">Здесь отображается полный список всех книг с нумерацией и пагинацией.</p>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-body table-responsive p-0">
          <table class="table table-hover text-nowrap table-bordered">
            <thead class="thead-dark">
              <tr>
                <th>#</th>
                <th>Название</th>
                <th>Год</th>
                <th>Издание</th>
                <th>Авторы</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              <?php $n = $offset + 1; ?>
              <?php foreach ($books as $book): ?>
                <tr>
                  <td><?= $n++ ?></td>
                  <td><?= htmlspecialchars($book['title']) ?></td>
                  <td><?= htmlspecialchars($book['year']) ?></td>
                  <td><?= htmlspecialchars($book['edition']) ?></td>
                  <td><?= implode(', ', array_column($book['authors'], 'name')) ?></td>
                  <td>
                    <a href="cardbook.php?id=<?= $book['id'] ?>" class="btn btn-sm btn-primary">Подробнее</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <nav aria-label="Навигация по страницам">
        <ul class="pagination justify-content-center mt-4">
          <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
              <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
            </li>
          <?php endfor; ?>
        </ul>
      </nav>

    </section>
  </div>

</div>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
