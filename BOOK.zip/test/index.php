<?php
require_once 'config.php';

session_start(); 
require_once 'config.php';

if (!isset($_SESSION['admin'])) {
  header("Location: login.php");
  exit;
}
$perPage = 5;

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $perPage;

$stmt = $pdo->prepare("
  SELECT books.* FROM books
  ORDER BY id DESC
  LIMIT :start, :perPage
");
$stmt->bindValue(':start', $start, PDO::PARAM_INT);
$stmt->bindValue(':perPage', $perPage, PDO::PARAM_INT);
$stmt->execute();
$books = $stmt->fetchAll();

$total = $pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
$totalPages = ceil($total / $perPage);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Библиотека</title>

  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<link rel="shortcut icon" href="log.png" type="image/png">
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <div class="content-wrapper p-4">
    <section class="content-header">
      <div class="container-fluid">
        <h1><i class="fas fa-book"></i> Библиотека</h1>
        <a href="dashboard.php" class="btn btn-success mt-3">Главная</a>
          <a href="add.php" class="btn btn-success mt-3">
          <i class="fas fa-plus"></i> Добавить книгу
          
        </a>
      </div>
      <br>
    </section>

    <section class="content">
      <div class="container-fluid">
        <?php foreach ($books as $book): ?>
          <?php
            $stmt = $pdo->prepare("
              SELECT a.* FROM authors a
              JOIN book_author ba ON ba.author_id = a.id
              WHERE ba.book_id = ?
            ");
            $stmt->execute([$book['id']]);
            $authors = $stmt->fetchAll();
          ?>
          <div class="card mb-3">
            <div class="card-header">
              <h3 class="card-title"><?= htmlspecialchars($book['title']) ?></h3>
              <div class="card-tools">
                                <a href="edit.php?id=<?= $book['id'] ?>" class="btn btn-warning btn-sm">
                  <i class="fas fa-edit"></i> Редактировать
                </a>
                <a href="delete.php?id=<?= $book['id'] ?>" class="btn btn-danger btn-sm"
                   onclick="return confirm('Точно удалить эту книгу?');">
                  <i class="fas fa-trash"></i> Удалить
                </a>
              </div>
            </div>
            <div class="card-body">
              <p><strong>Год:</strong> <?= htmlspecialchars($book['year']) ?></p>
              <p><strong>Издание:</strong> <?= htmlspecialchars($book['edition']) ?></p>
              <p><strong>Авторы:</strong> <?= htmlspecialchars(implode(', ', array_column($authors, 'name'))) ?></p>
            </div>
          </div>
        <?php endforeach; ?>

  
        <nav>
          <ul class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
              <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>

      </div>
    </section>
  </div>

</div>


<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
