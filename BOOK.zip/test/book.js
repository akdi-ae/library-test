$(function() {
  $('#authors').select2({
    tags: true,
    ajax: {
      url: '../api/authors.php',
      dataType: 'json',
      delay: 250,
      data: params => ({ q: params.term }),
      processResults: data => ({ results: data })
    }
  });

  function loadBooks() {
    $.get('../api/books.php', books => {
      let rows = '';
      books.forEach(book => {
        rows += `<tr>
          <td>${book.title}</td>
          <td>${book.year}</td>
          <td>${book.edition}</td>
          <td>${book.authors.map(a => a.name).join(', ')}</td>
          <td>
            <button class="btn btn-primary edit" data-id="${book.id}">✏️</button>
            <button class="btn btn-danger delete" data-id="${book.id}">🗑️</button>
          </td>
        </tr>`;
      });
      $('#books-table').html(rows);
    }, 'json');
  }
  loadBooks();

  $('#addBook').click(() => {
    $('#bookForm')[0].reset();
    $('#authors').val(null).trigger('change');
    $('input[name=id]').val('');
  });

  $(document).on('click', '.edit', function() {
    $.get('../api/books.php', { id: $(this).data('id') }, book => {
      $('input[name=id]').val(book.id);
      $('input[name=title]').val(book.title);
      $('input[name=year]').val(book.year);
      $('input[name=edition]').val(book.edition);

      $('#authors').empty();
      book.authors.forEach(a => {
        const opt = new Option(a.name, a.id, true, true);
        $('#authors').append(opt);
      });
      $('#authors').trigger('change');
      $('#bookModal').modal('show');
    }, 'json');
  });

  $('#bookForm').submit(function(e) {
    e.preventDefault();
    $.post('../api/books.php', $(this).serialize(), loadBooks);
    $('#bookModal').modal('hide');
  });

  $(document).on('click', '.delete', function() {
    if (confirm('Удалить?')) {
      $.ajax({
        url: '../api/books.php',
        type: 'DELETE',
        data: { id: $(this).data('id') },
        success: loadBooks
      });
    }
  });
});
