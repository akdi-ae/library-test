<?php
require_once 'config.php';
session_start();
if (!isset($_SESSION['admin'])) {
  header("Location: login.php");
  exit;
}
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];

  
    $stmt = $pdo->prepare("DELETE FROM book_author WHERE book_id = ?");
    $stmt->execute([$id]);

    
    $stmt = $pdo->prepare("DELETE FROM books WHERE id = ?");
    $stmt->execute([$id]);

    header("Location: index.php");
    exit;
}
?>