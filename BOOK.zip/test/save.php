<?php
require_once 'config.php';

$title = $_POST['title'] ?? '';
$year = $_POST['year'] ?? '';
$edition = $_POST['edition'] ?? '';
$authors = $_POST['authors'] ?? [];

if ($title && $year && $edition) {

  $stmt = $pdo->prepare("INSERT INTO books (title, year, edition) VALUES (?, ?, ?)");
  $stmt->execute([$title, $year, $edition]);
  $book_id = $pdo->lastInsertId();

  foreach ($authors as $author_id) {
    $stmt = $pdo->prepare("INSERT INTO book_author (book_id, author_id) VALUES (?, ?)");
    $stmt->execute([$book_id, $author_id]);
  }

  echo json_encode(['success' => true]);
} else {
  echo json_encode(['success' => false, 'message' => 'Не все поля заполнены']);
}
