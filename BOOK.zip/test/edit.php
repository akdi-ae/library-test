<?php
require_once 'config.php';
session_start();
if (!isset($_SESSION['admin'])) {
  header("Location: login.php");
  exit;
}

if (!isset($_GET['id'])) {
    die("ID книги не указан.");
}
$id = (int)$_GET['id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $year = $_POST['year'];
    $edition = $_POST['edition'];
    $authors = $_POST['authors'] ?? [];

  
    $stmt = $pdo->prepare("UPDATE books SET title = ?, year = ?, edition = ? WHERE id = ?");
    $stmt->execute([$title, $year, $edition, $id]);

    $stmt = $pdo->prepare("DELETE FROM book_author WHERE book_id = ?");
    $stmt->execute([$id]);

   
    foreach ($authors as $authorNameOrId) {
        if (is_numeric($authorNameOrId)) {
           
            $authorId = $authorNameOrId;
        } else {
           
            $stmt = $pdo->prepare("INSERT INTO authors (name) VALUES (?)");
            $stmt->execute([$authorNameOrId]);
            $authorId = $pdo->lastInsertId();
        }
       
        $stmt = $pdo->prepare("INSERT INTO book_author (book_id, author_id) VALUES (?, ?)");
        $stmt->execute([$id, $authorId]);
    }

    header("Location: index.php");
    exit;
}


$stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
$stmt->execute([$id]);
$book = $stmt->fetch();
if (!$book) {
    die("Книга не найдена.");
}

$stmt = $pdo->prepare("
    SELECT a.* FROM authors a
    JOIN book_author ba ON ba.author_id = a.id
    WHERE ba.book_id = ?
");
$stmt->execute([$id]);
$bookAuthors = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Редактировать книгу</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <link rel="shortcut icon" href="log.png" type="image/png">
</head>
<body class="p-5">
<div class="container">
  <h1>✏ Редактировать книгу</h1>

  <form method="POST">
    <div class="mb-3">
      <label for="title" class="form-label">Название книги</label>
      <input type="text" name="title" id="title" class="form-control" value="<?= htmlspecialchars($book['title']) ?>" required>
    </div>

    <div class="mb-3">
      <label for="year" class="form-label">Год выпуска</label>
      <input type="number" name="year" id="year" class="form-control" value="<?= htmlspecialchars($book['year']) ?>">
    </div>

    <div class="mb-3">
      <label for="edition" class="form-label">Издательство</label>
      <input type="text" name="edition" id="edition" class="form-control" value="<?= htmlspecialchars($book['edition']) ?>">
    </div>

    <div class="mb-3">
      <label for="authors" class="form-label">Авторы</label>
      <select name="authors[]" id="authors" class="form-control" multiple="multiple" style="width: 100%"></select>
    </div>

    <button type="submit" class="btn btn-success">Сохранить изменения</button>
    <a href="index.php" class="btn btn-secondary">Отмена</a>
  </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function() {
  $('#authors').select2({
    tags: true,
    ajax: {
      url: 'api/authors.php',
      dataType: 'json',
      delay: 250,
      data: function (params) {
        return {
          q: params.term
        };
      },
      processResults: function (data) {
        return {
          results: data
        };
      },
      cache: true
    }
  });

  <?php foreach ($bookAuthors as $author): ?>
    var option = new Option("<?= htmlspecialchars($author['name']) ?>", <?= $author['id'] ?>, true, true);
    $('#authors').append(option);
  <?php endforeach; ?>
  $('#authors').trigger('change');
});
</script>
</body>
</html>
