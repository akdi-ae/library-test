
document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.getElementById("login-form");

  if (loginForm) {
    loginForm.addEventListener("submit", function (e) {
      e.preventDefault();

      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;

      if (username === "admin" && password === "123456") {

        localStorage.setItem("loggedIn", "true");
        window.location.href = "admin.html";
      } else {
        document.getElementById("error-message").style.display = "block";
      }
    });
  }


  if (window.location.pathname.includes("admin.html")) {
    const isLoggedIn = localStorage.getItem("loggedIn");
    if (isLoggedIn !== "true") {
      window.location.href = "login.html";
    }
  }
});
$(document).ready(function() {

  $('#authors').select2({
    tags: true,
    ajax: {
      url: 'ajax_search_authors.php',
      dataType: 'json',
      delay: 250,
      data: params => ({ q: params.term }),
      processResults: data => ({ results: data })
    }
  });


  function loadBooks() {
    $.get('get_books.php', function(books) {
      let rows = '';
      books.forEach(book => {
        rows += `<tr>
          <td>${book.title}</td>
          <td>${book.year}</td>
          <td>${book.edition}</td>
          <td>${book.authors.map(a => a.name).join(', ')}</td>
          <td>
            <button class="btn btn-sm btn-primary edit-book" data-id="${book.id}">✏️</button>
            <button class="btn btn-sm btn-danger delete-book" data-id="${book.id}">🗑️</button>
          </td>
        </tr>`;
      });
      $('#books-table').html(rows);
    }, 'json');
  }
  loadBooks();

  $('[data-target="#bookModal"]').on('click', function() {
    $('#bookForm')[0].reset();
    $('#book_id').val('');
    $('#authors').val(null).trigger('change');
    $('.modal-title').text('Добавить книгу');
  });

  $(document).on('click', '.edit-book', function() {
    const id = $(this).data('id');
    $.get('get_book.php', { id }, function(data) {
      $('#book_id').val(data.id);
      $('#title').val(data.title);
      $('#year').val(data.year);
      $('#edition').val(data.edition);

      $('#authors').empty();
      data.authors.forEach(a => {
        const option = new Option(a.name, a.id, true, true);
        $('#authors').append(option);
      });
      $('#authors').trigger('change');

      $('.modal-title').text('Редактировать книгу');
      $('#bookModal').modal('show');
    }, 'json');
  });
  
  $(document).on('click', '.delete-book', function() {
    if (confirm('Удалить книгу?')) {
      const id = $(this).data('id');
      $.post('delete_book.php', { id }, function() {
        loadBooks();
      });
    }
  });


  $('#bookForm').submit(function(e) {
    e.preventDefault();
    $.post('save_book.php', $(this).serialize(), function() {
      $('#bookModal').modal('hide');
      loadBooks();
    });
  });

});
