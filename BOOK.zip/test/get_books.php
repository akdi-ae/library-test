<?php
header('Content-Type: application/json');
$pdo = new PDO('mysql:host=localhost;dbname=library', 'root', ''); // Замени на свои


$sql = "SELECT b.id, b.title, b.year, b.edition, a.id AS author_id, a.name AS author_name
        FROM books b
        LEFT JOIN book_author ba ON b.id = ba.book_id
        LEFT JOIN authors a ON ba.author_id = a.id
        ORDER BY b.id DESC";

$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$books = [];
foreach ($rows as $row) {
  $id = $row['id'];
  if (!isset($books[$id])) {
    $books[$id] = [
      'id' => $row['id'],
      'title' => $row['title'],
      'year' => $row['year'],
      'edition' => $row['edition'],
      'authors' => []
    ];
  }
  if ($row['author_id']) {
    $books[$id]['authors'][] = [
      'id' => $row['author_id'],
      'name' => $row['author_name']
    ];
  }
}

echo json_encode(array_values($books));
