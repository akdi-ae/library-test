<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit;
}


$perPage = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $perPage;

$stmt = $pdo->prepare("SELECT * FROM books ORDER BY id DESC LIMIT :start, :perPage");
$stmt->bindValue(':start', $start, PDO::PARAM_INT);
$stmt->bindValue(':perPage', $perPage, PDO::PARAM_INT);
$stmt->execute();
$books = $stmt->fetchAll();

$total = $pdo->query("SELECT COUNT(*) FROM books")->fetchColumn();
$totalPages = ceil($total / $perPage);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>Админка — Книги</title>
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <div class="content-wrapper p-4">
    <section class="content-header">
      <div class="container-fluid">
        <h1><i class="fas fa-book"></i> Книги</h1>
        <a href="add_book.php" class="btn btn-primary mb-3">
          <i class="fas fa-plus"></i> Добавить книгу
        </a>
      </div>
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="card">
          <div class="card-body p-0">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Название</th>
                  <th>Год</th>
                  <th>Издание</th>
                  <th>Действия</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($books as $book): ?>
                  <tr>
                    <td><?= htmlspecialchars($book['title']) ?></td>
                    <td><?= htmlspecialchars($book['year']) ?></td>
                    <td><?= htmlspecialchars($book['edition']) ?></td>
                    <td>
                      <a href="edit_book.php?id=<?= $book['id'] ?>" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Редактировать
                      </a>
                      <a href="delete_book.php?id=<?= $book['id'] ?>" class="btn btn-danger btn-sm"
                         onclick="return confirm('Точно удалить эту книгу?');">
                        <i class="fas fa-trash"></i> Удалить
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>

        <nav>
          <ul class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
              <li class="page-item <?= ($i == $page) ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>

      </div>
    </section>
  </div>

</div>

<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
