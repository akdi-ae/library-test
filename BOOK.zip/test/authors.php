<?php
require_once '../config.php';

$q = $_GET['q'] ?? '';
$stmt = $pdo->prepare("SELECT id, name as text FROM authors WHERE name LIKE ?");
$stmt->execute(["%$q%"]);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
